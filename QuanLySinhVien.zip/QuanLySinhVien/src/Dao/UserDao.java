/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Connect.Connects;
import User.SinhVien;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author Admin
 */
public class UserDao {
    public boolean insert(SinhVien sv) throws Exception{
        String sql = "insert into SINHVIEN(MaSV,HoTen,NgaySinh,GioiTinh,DiaChi) values(?,?,?,?,?)";
            Connection conn = Connects.openConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, sv.getMaSV());
            pstmt.setString(2, sv.getTenSV());
            pstmt.setString(3, sv.getNgaySinh());
            pstmt.setInt(4, sv.getGioiTinh());
            pstmt.setString(5, sv.getDiaChi());
            return pstmt.executeUpdate() > 0;
        }
}
